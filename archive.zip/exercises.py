names = ["john smith", "jay santi", "eva kuki"]
[print(name.title()) for name in names]

usernames = ["john 1990", "alberta1970", "magnola2000"]
[print(len(i)) for i in usernames]

user_entries = ["10", "19.1", "20"]
[print(float(i)) for i in user_entries]

print(sum([float(i) for i in user_entries]))
