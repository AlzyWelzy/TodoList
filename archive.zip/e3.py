import shutil

# make a archive of all files in this directory
shutil.make_archive("archive", "zip", root_dir="./")
