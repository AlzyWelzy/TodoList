def litre_cube(litre):
    return litre / 1000


print(litre_cube(1000))  # 1.0
